﻿/*
 * Test asumptions:
 * 
 * 1)   Find anagrams that are actual words by going throught the provided dictionary to find words
 * 2)   Since the main fucntion in program.cs has a timer to see how long it takes to compute finding the anagrams speed is important, thus functions should be optimized as much as possible
 * 3)   Since the test asks to find anagrams for a given list of words but the list of words are not given, a string array or list of words will be made and used for the test
 * 4)   Since the test allows for modifications to be made and processing speed is important instead for looping through all the words in the dictionary to find anagrams
 *      I will make use of the C# Dictionary key value pairs to create a generic collection of words, where the key is an aplhabetized char array which corresponds to a list of words that are anargrms of the key
 *      (note for 4: even though changes will be made to the programs I will try to not change to much to incase preserving the original structure is part of the test)
 * 5)   Lastly eventhough not required to show that the program works for test purposes it will display the anagrams that were found
 * 
 *      comments will be provided to make going through the test easier 
 * 
 */

namespace DotNetRecruit
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class AnagramService
    {
        protected static int c1, c2, c3, c4, c5, c6, c7, c8, c9, c10 = 0;   // variables to count the number of anagrms for each word length and set to 0

        public IEnumerable<AnagramCounter> Compute(string dictionaryLocation)
        {
            var ReadWords = File.ReadAllLines(dictionaryLocation);  // get all the words that are in Dictionary.txt
            Dictionary<Char[], List<string>> OrderedDic = new Dictionary<Char[], List<string>>(new CarrayComparer());    // create a new Dictionary that will be ordered 
            foreach (var tempWord in ReadWords)     // loop through all the words in the dictionary 
            {
             
                List<string> NewWords;      // create list to store all the 
                Char[] key = ToAplhabetizeArray(tempWord);      // take the word alphebetize it and create key
                if (!OrderedDic.TryGetValue(key, out NewWords))     // if not in the dictionary already
                {
                    NewWords = new List<string>();      // create list for the key value
                    OrderedDic.Add(key, NewWords);      // add it ot the dictionary 
                }
                NewWords.Add(tempWord);     // if the key exists then add the word to the lits that corresponds to the key 

            }

            string[] inputs = new String[10] {"teaser", "senator", "spare", "altering", "adnor", "apple", "estain", "introduces", "bare", "cat"}; // words from https://www.reddit.com/r/answers/comments/13o511/what_is_the_word_with_the_most_anagrams/
            foreach (string tempinput in inputs)
            {
                Console.Write(string.Format("{0}Searched Word: ", Environment.NewLine));     // just to show the words that has been searched
                Console.WriteLine(tempinput);       // show the words searched

                IEnumerable<string> Anagrams = OrderedDic[ToAplhabetizeArray(tempinput)];    // list of anagrams for each input

                foreach (string dicword in Anagrams)    // check against words in the ordered dictionary 
                {
                    Console.WriteLine(dicword);    // print anagrams for the word 
                    switch (tempinput.Length)
                    {
                            case 1:
                                c1++;
                                break;
                            case 2:
                                c2++;
                                break;
                            case 3:
                                c3++;
                                break;
                            case 4:
                                c4++;
                                break;
                            case 5:
                                c5++;
                                break;
                            case 6:
                                c6++;
                                break;
                            case 7:
                                c7++;
                                break;
                            case 8:
                                c8++;
                                break;
                            case 9:
                                c9++;
                                break;
                            case 10:
                                c10++;
                                break;
                    }
                }
            } 

            // only changed the char count part of given code 
            return new List<AnagramCounter>
                       {
                           new AnagramCounter { WordLength = 1, Count = c1 },
                           new AnagramCounter { WordLength = 2, Count = c2 },
                           new AnagramCounter { WordLength = 3, Count = c3 },
                           new AnagramCounter { WordLength = 4, Count = c4 },
                           new AnagramCounter { WordLength = 5, Count = c5 },
                           new AnagramCounter { WordLength = 6, Count = c6 },
                           new AnagramCounter { WordLength = 7, Count = c7 },
                           new AnagramCounter { WordLength = 8, Count = c8 },
                           new AnagramCounter { WordLength = 9, Count = c9 },
                           new AnagramCounter { WordLength = 10, Count = c10 }
                       };
        }

        static Char[] ToAplhabetizeArray(string Source)     // create char array and aphebetize the array as well
        {
            char[] Carry = Source.ToUpper().ToCharArray();      // create upper case char array from given string
            Array.Sort(Carry);      // alphebetize 
            return Carry;       // return the array 
        }

    }


    // basic C# char equality comparer from https://www.dotnetperls.com/iequalitycomparer and https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.equalitycomparer-1?view=netframework-4.8
    // checks if the keys from the words in dictionary.txt are they same i.e. if cat and act => act when aplhebetized thus cat and act will be in the same list
    internal class CarrayComparer : EqualityComparer<Char[]>
    {
        private static readonly EqualityComparer<Char> checks = EqualityComparer<Char>.Default;
        public override bool Equals(char[] key1, char[] key2)
        {
            if (key1 == null) return false;     // if null then false (not equal)
            if (key2 == null) return false;     // if null then false (not equal)

            if (key1.Length != key2.Length)     // if not the same length then false (not equal)
            {
                return false;
            }
            for (int i = 0; i < key1.Length; i++)
            {
                if (!checks.Equals(key1[i], key2[i]))       // if not equal then false (not same chars)
                {
                    return false;
                }
            }
            return true;        // else they are equal so return true 
        }

        public override int GetHashCode(char[] chararr)     // get hash code method, has to be there for comparer but not important so used dotnet pearls override method
        {
            unchecked       // unchecked since we don't care if the reurned hash overflows or not
            {
                if (chararr == null) return 0;      // if the object is null then return zero
                int hash = 0;       // var to store the has value and set to 0

                foreach (char Item in chararr)      // for each item in the object then calc the hash
                {
                    hash = (((hash << 5) - hash) ^ checks.GetHashCode(Item));       // cal the hash
                }
                return hash;
            }
        }
    }

}
